/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package animal.main;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Locale;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;





import translator.Translator;
import animal.gui.AnimalMainWindow;
import animal.main.icons.LoadIcon;

/**
 *
 * @author Wester
 */
public class AnimationExtrasBar extends JPanel{

    /**
   * 
   */
  private static final long serialVersionUID = 1L;
    private AnimationWindow animationWindow;
    private static final double[] scale = {0.5, 0.75, 1.0, 1.5, 2.0, 3.0, 4.0};
    private static final String[] scaleName = {"50%","75%","100%","150%","200%","300%","400%"};
    
    private Translator translator;
    private JComboBox<String> mag;
    private JButton snapshot;

    public AnimationExtrasBar(AnimationWindow controller) {

      // store the reference to the AnimationWindow instance
      // if null, create it first!
      if (controller != null)
        animationWindow = controller;
      else
        animationWindow = AnimalMainWindow.getWindowCoordinator().getAnimationWindow(true);
      
      this.translator = new Translator("AnimationFrame", Animal.getCurrentLocale());
      init();
    }

    private void init() {
      // TODO Auto-generated method stub
      setLayout(new BorderLayout(0, 0));
      LoadIcon get = new LoadIcon();
      snapshot = new JButton();
      snapshot.setIcon(get.createSnapShotIcon());
      snapshot.addActionListener(new ActionListener(){

        @Override
        public void actionPerformed(ActionEvent arg0) {
          // TODO Auto-generated method stub
          animationWindow.setSnapshot();
        }
      });
      
      add(BorderLayout.EAST, snapshot);
      JPanel pane = new JPanel();
      JLabel l = new JLabel("Zoom");
      pane.add(l);
      mag = new JComboBox<String>(scaleName);
      
      mag.setOpaque(true);
      mag.setVisible(true);
      mag.setLightWeightPopupEnabled(false);
      mag.setSelectedIndex(2);
      mag.addActionListener(new ActionListener(){

        @Override
        public void actionPerformed(ActionEvent e) {
          // TODO Auto-generated method stub
          double value = scale[mag.getSelectedIndex()];
          animationWindow.setMagnification(value);
        }
        
      });
      
      pane.add(mag);
      add(BorderLayout.WEST, pane);
      
      mag.setToolTipText(translator.translateMessage("zoom"));
      snapshot.setToolTipText(translator.translateMessage("snapshot"));
      
    }

    public void changeLocale(Locale targetLocale) {
      // TODO Auto-generated method stub
      translator.setTranslatorLocale(Animal.getCurrentLocale());
      mag.setToolTipText(translator.translateMessage("zoom"));
      snapshot.setToolTipText(translator.translateMessage("snapshot"));
    }
    
}