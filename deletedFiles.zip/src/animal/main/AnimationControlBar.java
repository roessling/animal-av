/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package animal.main;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Locale;

import animal.gui.AnimalMainWindow;
import animal.main.icons.LoadIcon;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSlider;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import translator.Translator;

/**
 *
 * @author Wester
 */
public class AnimationControlBar extends JPanel{
    
    /**
   * 
   */
  private static final long serialVersionUID = 1L;
  
    private AnimationWindow animationWindow;

    private JButton stop;

    private JButton play;

    private JButton playBack;
    
    private Translator translator;
    
    private int maxStep = 0;
    
    private boolean slideMode = false;
   
    private JSlider speed;
    private JLabel label;
   
    /**
   * creates the main tool bar for Animal
   *
   * @param title not used at the moment
   * @param anAnimWindow the concrete AnimationWindow instance
   * for which the toolbar is instantiated.
   */
  public AnimationControlBar(AnimationWindow anAnimWindow) {

    // store the reference to the AnimationWindow instance
    // if null, create it first!
    if (anAnimWindow != null)
      animationWindow = anAnimWindow;
    else
      animationWindow = AnimalMainWindow.getWindowCoordinator().getAnimationWindow(true);
    
    this.translator = new Translator("AnimationFrame", Animal.getCurrentLocale());
    init();
  }
  
  private void init(){
      
      LoadIcon get = new LoadIcon();
      setLayout(new BorderLayout(0,0));
      JPanel pane = new JPanel();
      stop = new JButton();
      stop.setIcon(get.createPauseIcon());
      stop.addActionListener(new ActionListener(){

        @Override
        public void actionPerformed(ActionEvent arg0) {
          // TODO Auto-generated method stub
          animationWindow.pauseAnimation();
        }
      });
      
      
      
      
      play = new JButton();
      play.setIcon(get.createPlayIcon());
      play.addActionListener(new ActionListener(){

        @Override
        public void actionPerformed(ActionEvent arg0) {
          // TODO Auto-generated method stub
          animationWindow.slideShow();
        }
      });
      pane.add(play);
      pane.add(stop);
      
      playBack = new JButton();
      playBack.setIcon(get.createPlayBackwardsIcon());
      playBack.addActionListener(new ActionListener(){

        @Override
        public void actionPerformed(ActionEvent arg0) {
          // TODO Auto-generated method stub
          animationWindow.reverseSlideShow();
        }
      });
      pane.add(playBack);
      
      JPanel speedpane = new JPanel();
      label = new JLabel("Speed");
      speed = new JSlider(JSlider.HORIZONTAL);
      speed.setMaximum((int)AnimationWindow.MAX_SPEED_FACTOR);
      speed.setMinimum(0);
      speed.setValue(1);
      speed.setMajorTickSpacing(5);
      speed.setMinorTickSpacing(1);
      speed.setPaintTicks(true);
      speed.setPaintLabels(true);
      speed.addChangeListener(new ChangeListener(){

        @Override
        public void stateChanged(ChangeEvent arg0) {
          // TODO Auto-generated method stub
            double speedValue = (double)speed.getValue();
            
            animationWindow.setSpeed(speedValue);
            
        }});
      speedpane.add(speed);
      speedpane.add(label);
      pane.add(speedpane);
      
      JPanel space = new JPanel();
      space.setMinimumSize(new Dimension(40,40));
      add(BorderLayout.NORTH, space);
      add(BorderLayout.CENTER, pane);
      
      stop.setToolTipText(translator.translateMessage("stop"));
      play.setToolTipText(translator.translateMessage("play"));
      playBack.setToolTipText(translator.translateMessage("reverse"));
      speed.setToolTipText(translator.translateMessage("speedSlider"));
      label.setText(translator.translateMessage("speed"));
  }
  
  public void determineButtonState(int step){
    if(!playBack.isEnabled()){
      playBack.setEnabled(true);
    }
    if(!play.isEnabled()){
      play.setEnabled(true);
    }
    
    
    
    if(step <= 1){
      playBack.setEnabled(false);
      slideMode = false;
    }else{
      if(step == maxStep){
        play.setEnabled(false);
        slideMode = false;
      }else{
        if(slideMode){
          play.setEnabled(false);
          playBack.setEnabled(false);
          stop.setEnabled(true);
        }else{
          play.setEnabled(true);
          playBack.setEnabled(true);
          stop.setEnabled(false);
        }
      }
    }
    
    
    
//    if(specialEnable || slideMode){
//      
//      play.setEnabled(values[0]);
//      
//      stop.setEnabled(values[1]);
//      playBack.setEnabled(values[2]);
//      
//      specialEnable = false;
//    }
    
  }
  
  public void setSlideMode(boolean on){
    
    slideMode = on;
    if(!on){
      play.setEnabled(true);
      playBack.setEnabled(true);
      stop.setEnabled(false);
    }
  }
  
  public void enablePlayButton(boolean enable){
    play.setEnabled(enable);
    
  }
  
  public void enablePlayButton(boolean p, boolean pause, boolean reverse){
    if(p && reverse){
      slideMode = false;
    }
    play.setEnabled(p);
    
    stop.setEnabled(pause);
    playBack.setEnabled(reverse);
    
   
    
  }

  public void changeLocale(Locale targetLocale) {
    // TODO Auto-generated method stub
    translator.setTranslatorLocale(Animal.getCurrentLocale());
    stop.setToolTipText(translator.translateMessage("stop"));
    play.setToolTipText(translator.translateMessage("play"));
    playBack.setToolTipText(translator.translateMessage("reverse"));
    speed.setToolTipText(translator.translateMessage("speedSlider"));
    label.setText(translator.translateMessage("speed"));
  }

  public void maxStep(int n) {
    // TODO Auto-generated method stub
    maxStep = n;
  }
  
 
}

