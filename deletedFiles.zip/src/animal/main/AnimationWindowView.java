package animal.main;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Frame;
import java.awt.Image;
import java.awt.Rectangle;
import java.awt.ScrollPane;
import java.awt.Toolkit;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.util.Locale;

import javax.swing.BoxLayout;
import javax.swing.JPanel;
import javax.swing.JSplitPane;

import animal.gui.GraphicVector;
import animal.misc.XProperties;

/**
 * The Window that displays the animation. Contains a Panel for control (play,
 * rewind, forward...) in its south and an AnimationCanvas that contains the
 * GraphicObjects in its center.
 */

public class AnimationWindowView extends AnimalFrame{
  /**
   * 
   */
  private static final long serialVersionUID = 1L;
  
  private Container workContainer = null;
  private JSplitPane main = null;
  private ScrollPane scrollMain = null;
  private ScrollPane scrollClip = null;
  private AnimationWindow controller = null;
 
  /** AnimationCanvas to display the GraphicObjects. */
  private AnimationCanvas animationCanvas;
  
  private AnimationControlBar bottom;
  private AnimationExtrasBar top;
  private SlideControlBar side;
  

  /**
   * construct an AnimationWindow. Actual initialization is done in
   * <code>init</code>.
   * 
   * @param animalInstance
   *          the current Animal instance
   * @param properties
   *          the current animation properties
   * @see #init()
   */
  public AnimationWindowView(Animal animalInstance, XProperties properties, AnimationWindow controller) {
    super(animalInstance, properties);
    this.controller = controller;
    setDependentContainer(getContentPane());
  }

  /**
   * construct an AnimationWindow. Actual initialization is done in
   * <code>init</code>.
   * 
   * @param animalInstance
   *          the current Animal instance
   * @param properties
   *          the current animation properties
   * @param aContainer
   *          the container that contains this component
   * @see #init()
   */
  public AnimationWindowView(Animal animalInstance, XProperties properties,
      Container aContainer, AnimationWindow controller) {
      
    super(animalInstance, properties);
    this.controller = controller;
    setDependentContainer(aContainer);
  }

  /**
   * Sets the container that contains this component
   * 
   * @param aContainer
   *          the container for this component
   */
  public void setDependentContainer(Container aContainer) {
    workContainer = aContainer;
  }
  
  public AnimationCanvas getAnimationCanvas(){
      return animationCanvas;
  }
  
  public void setCanvasObject(GraphicVector g, GraphicVector gc){
      animationCanvas.setObjects(g);
  }
  
  public void setNrOfSteps(int n){
      side.setSteps(n);
      bottom.maxStep(n);
  }
  /**
   * returns the work container for this component
   * 
   * @return the work container of this component
   */
  public Container workContainer() {
    return workContainer;
  }
  
  public void setMagnification(double scale){
      animationCanvas.setMagnification(scale);
  }
  
  public double getMagnification(){
      return animationCanvas.getMagnification();
  }
  
  public void updateCanvas(){
      animationCanvas.repaintNow();
  }
  
  public Image slowModeStep(){
      Image i = getCurrentImage();
      animationCanvas.invalidateImage();
      return i;
  }
  
  protected Image getCurrentImage(){
      return animationCanvas.getCurrentImage();
  }
  
  public ScrollPane getScrollPane(){
      return scrollMain;
  }
				
  /**
   * initializes the AnimationWindow by adding the control panel and the
   * AnimationCanvas.
   */
  public void init() {
    super.init();
    super.pack();
    super.setLocationRelativeTo(null);
    setTitle("Animal Animation");
    workContainer().setLayout(new BorderLayout(0, 0));
    top = new AnimationExtrasBar(controller);
    
    workContainer().add(BorderLayout.NORTH, top);
    // create the animation controls tool bar
 //   animationControlToolBar = new AnimationControlToolBar("AnimationControls",
 //       this);

    // add the toolbar to the "south" of the window
//    workContainer().add(BorderLayout.SOUTH, animationControlToolBar);

    // create the animation display tool bar
 //   displayControlToolBar = new AnimationDisplayToolBar(
 //       "Animation Display Controls", this);

    // add the toolbar to the "north" of the window
 //   workContainer().add(BorderLayout.NORTH, displayControlToolBar);

    
    if (animationCanvas == null) {
      animationCanvas = new AnimationCanvas();
    }
 
    animationCanvas.setProperties(props);
    
    if (scrollMain == null) {
        scrollMain = new ScrollPane();
    }
    
    if(scrollClip == null){
      scrollClip = new ScrollPane();
    }
      // sp = new JScrollPane();
    scrollMain.add(animationCanvas);
  //  }
    Dimension dim = getSize();
    scrollMain.setMinimumSize(new Dimension((int)dim.getWidth()/9, (int)dim.getHeight()));
    scrollClip.setMinimumSize(new Dimension((int)dim.getWidth()/9, (int)dim.getHeight()));
    
    checkandsetVisibility_scrollClip();
  
    main = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, scrollMain, scrollClip);
    //main.setOneTouchExpandable(true);
    //main.setDividerLocation(600);
    main.setResizeWeight(0.9);

    
    //main.setRightComponent();
    
    workContainer().add(BorderLayout.CENTER, main);


  //  workContainer().add(BorderLayout.CENTER, sp); // was: animationCanvas
  //  setTitle("Animal Animation");
    JPanel bottonPane = new JPanel();
    bottonPane.setLayout(new BoxLayout(bottonPane, BoxLayout.Y_AXIS));
    side = new SlideControlBar(controller);
    bottonPane.add(side);
    bottom = new AnimationControlBar(controller);
    bottonPane.add(bottom);
    workContainer().add(BorderLayout.SOUTH, bottonPane);

    setProperties(props);
    this.setExtendedState(Frame.MAXIMIZED_BOTH);
    this.setMaximumSize(new Dimension((int)Toolkit.getDefaultToolkit().getScreenSize().getWidth(), (int)Toolkit.getDefaultToolkit().getScreenSize().getHeight()-300));
  }
  
  public void setSizes(int w, int h){
    if(h > (int)Toolkit.getDefaultToolkit().getScreenSize().getHeight()-300){
      h = (int)Toolkit.getDefaultToolkit().getScreenSize().getHeight()-300;
    }
    setSize(w, h);
    side.setLength(w);
  }
  
  /**
   * initializes the AnimationWindow's bounds.
   * 
   * @param props
   *          the properties to set (concerns the window coordinates and
   *          bounds).
   */
  void setProperties(XProperties properties) {
    setBounds(properties.getIntProperty("animationWindow.x", 50), 
        properties.getIntProperty("animationWindow.y", 50), 
        properties.getIntProperty("animationWindow.width", 400),
        properties.getIntProperty("animationWindow.height", 200));
  }
  
  /**
	 * stores the window location into the properties passed in
	 * 
	 * @param props
	 *          the properties in which the window location is to be stored
	 */
    void getProperties(XProperties properties) {
		Rectangle b = getBounds();

		if (((b.width - 10) == properties.getIntProperty("animationWindow.width", 320))
				&& ((b.height - 22) == properties.getIntProperty("animationWindow.height",
						200))) {
			b.width -= 10;
			b.height -= 22;
		}

		properties.put("animationWindow.x", b.x);
		properties.put("animationWindow.y", b.y);
		properties.put("animationWindow.width", b.width);
		properties.put("animationWindow.height", b.height);
    }
    
    
    public void updateSlider(int step, AnimationState state){
        //TODO SlideControlBar
      side.setStep(step);
    }
    
    public void determineButtonState(int step){
        //TODO AnimationCOntrolBAr
      bottom.determineButtonState(step);
      side.determineButtonState(step);
    }
    
    protected void enablePlayButton(boolean enable){
        //TODO AnimationCOntrolBAr
      bottom.enablePlayButton(enable);
    }
    
    protected void enablePlayButton(boolean play, boolean pause, boolean reverse){
      //TODO AnimationCOntrolBAr
      bottom.enablePlayButton(play, pause, reverse);
    }

    public void slideMode(boolean b) {
      // TODO Auto-generated method stub
      
      bottom.setSlideMode(b);
      side.slideMode(b);
    }

    public void changeLocale(Locale targetLocale) {
      // TODO Auto-generated method stub
      side.changeLocale(targetLocale);
      bottom.changeLocale(targetLocale);
      top.changeLocale(targetLocale);
    }
    
    private boolean isScreenshoted = false;
    public void setScreenshoted(boolean isScreenshoted) {
      boolean old_isScreenshote = this.isScreenshoted;
      this.isScreenshoted = isScreenshoted;
      checkandsetVisibility_scrollClip();
      if(isScreenshoted==true && old_isScreenshote==false) {
        main.setDividerLocation(0.8);
        main.addPropertyChangeListener(JSplitPane.DIVIDER_LOCATION_PROPERTY, new PropertyChangeListener() {
          @Override
          public void propertyChange(PropertyChangeEvent evt) {
//            updateAllUIs();
            updateCanvas();
            main.repaint();
            workContainer().repaint();
            scrollClip.repaint();
            scrollClip.revalidate();
            for(java.awt.Component s : scrollClip.getComponents()) {
              s.paint(s.getGraphics());
            }
            
          }
        });
        updateAllUIs();
      }
    }
    public boolean isScreenshoted() {
      return isScreenshoted;
    }
    public void checkandsetVisibility_scrollClip() {
      scrollClip.setVisible(isScreenshoted());
      scrollClip.repaint();
    }
    
    public void setScrollClipPanel(JPanel panel) {
      scrollClip.removeAll();
      scrollClip.add(panel);
    }
    
    private void updateAllUIs() {
      updateCanvas();
      main.updateUI();
      main.repaint();
      workContainer().repaint();
      scrollClip.repaint();
    }
}
