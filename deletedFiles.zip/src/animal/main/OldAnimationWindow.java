package animal.main;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.Image;
import java.awt.Rectangle;
import java.awt.ScrollPane;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Vector;

import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;
import javax.swing.Timer;

import animal.animator.Animator;
import animal.graphics.PTGraphicObject;
import animal.gui.AnimalMainWindow;
import animal.gui.AnimationControlToolBar;
import animal.gui.AnimationDisplayToolBar;
import animal.gui.GraphicVector;
import animal.misc.XProperties;

/**
 * The Window that displays the animation. Contains a Panel for control (play,
 * rewind, forward...) in its south and an AnimationCanvas that contains the
 * GraphicObjects in its center.
 * 
 * @author <a href="http://www.ahrgr.de/guido/">Guido
 *         R&ouml;&szlig;ling</a>
 * @version 1.0 13.07.1998
 */
public class OldAnimationWindow extends AnimalFrame implements ActionListener {
  /**
   * Comment for <code>serialVersionUID</code>
   */
  private static final long serialVersionUID = -5650098641898883312L;

  public static final double MAX_SPEED_FACTOR = 10.0;

  public static final int PADDING_SCROLLBAR_RIGHT = 20;

  public static final int PADDING_TOOLBARS_TOP_BOTTOM = 80;

  /** the AnimationState to work with */
  private AnimationState ani = null;

  /** AnimationCanvas to display the GraphicObjects. */
  private AnimationCanvas animationCanvas;

  private ScrollPane sp;

  // private JScrollPane sp;

  /**
   * determines whether a pause is to be done after the next step if they are
   * linked with a time link. If there is a key link, a pause is done anyway.
   * will be checked in setStep before the next step is set
   */
  private boolean pause = false;

  private boolean slideShowMode = false;

  private boolean forwardMode = true;

  /**
   * ticks elapsed since AnimationStart. Needed for synchronisation of the
   * Animation
   */
  private double ticks;

  private Timer timer;

  private double speed = 1;

  private boolean isSlowMode = false;

  private Vector<Image> animationImages = new Vector<Image>(50, 15);

  private Container workContainer = null;

  private AnimationControlToolBar animationControlToolBar;

  private AnimationDisplayToolBar displayControlToolBar;

  /**
   * construct an AnimationWindow. Actual initialization is done in
   * <code>init</code>.
   * 
   * @param animalInstance
   *          the current Animal instance
   * @param properties
   *          the current animation properties
   * @see #init()
   */
  public OldAnimationWindow(Animal animalInstance, XProperties properties) {
    super(animalInstance, properties);
    setDependentContainer(getContentPane());
  }

  /**
   * construct an AnimationWindow. Actual initialization is done in
   * <code>init</code>.
   * 
   * @param animalInstance
   *          the current Animal instance
   * @param properties
   *          the current animation properties
   * @param aContainer
   *          the container that contains this component
   * @see #init()
   */
  public OldAnimationWindow(Animal animalInstance, XProperties properties,
      Container aContainer) {
    super(animalInstance, properties);
    setDependentContainer(aContainer);
  }

  /**
   * Sets the container that contains this component
   * 
   * @param aContainer
   *          the container for this component
   */
  public void setDependentContainer(Container aContainer) {
    workContainer = aContainer;
  }

  /**
   * returns the work container for this component
   * 
   * @return the work container of this component
   */
  public Container workContainer() {
    return workContainer;
  }

  /**
   * initializes the AnimationWindow by adding the control panel and the
   * AnimationCanvas.
   */
  public void init() {
    super.init();
    workContainer().setLayout(new BorderLayout(0, 0));

    // create the animation controls tool bar
   // animationControlToolBar = new AnimationControlToolBar("AnimationControls",
    //    this);

    // add the toolbar to the "south" of the window
    workContainer().add(BorderLayout.SOUTH, animationControlToolBar);

    // create the animation display tool bar
  //  displayControlToolBar = new AnimationDisplayToolBar(
   //     "Animation Display Controls", this);

    // add the toolbar to the "north" of the window
    workContainer().add(BorderLayout.NORTH, displayControlToolBar);

    if (animationCanvas == null) {
      animationCanvas = new AnimationCanvas();
    }

    animationCanvas.setProperties(props);

    if (sp == null) {
      sp = new ScrollPane();

      // sp = new JScrollPane();
      sp.add(animationCanvas);
    }

    workContainer().add(BorderLayout.CENTER, sp); // was: animationCanvas
    setTitle("Animal Animation");

    setProperties(props);
  }

  /**
   * overwritten to initialize the internal Animation. When the window is not
   * visible, all methods can be called, but they don't make a change until the
   * window is made visible. Then perform the commands from here.
   * 
   * @param isVisible
   *          if true, ensure the window is visible
   */
  public void setVisible(boolean isVisible) {
    super.setVisible(isVisible);

    if (isVisible) {
      if (ani == null) {
        setAnimation(Animation.get());
        setStep(ani.getStep(), true);
      }
    }
  }

  /**
   * initializes the AnimationWindow's bounds.
   * 
   * @param props
   *          the properties to set (concerns the window coordinates and
   *          bounds).
   */
  void setProperties(XProperties properties) {
    setBounds(properties.getIntProperty("animationWindow.x", 50), 
        properties.getIntProperty("animationWindow.y", 50), 
        properties.getIntProperty("animationWindow.width", 400),
        properties.getIntProperty("animationWindow.height", 200));
  }

  /**
   * stores the window location into the properties passed in
   * 
   * @param props
   *          the properties in which the window location is to be stored
   */
  void getProperties(XProperties properties) {
    Rectangle b = getBounds();

    if (((b.width - 10) == properties.getIntProperty("animationWindow.width", 320))
        && ((b.height - 22) == properties.getIntProperty("animationWindow.height",
            200))) {
      b.width -= 10;
      b.height -= 22;
    }

    properties.put("animationWindow.x", b.x);
    properties.put("animationWindow.y", b.y);
    properties.put("animationWindow.width", b.width);
    properties.put("animationWindow.height", b.height);
  }

  /**
   * jump to the start of the animation
   */
  public void startOfAnimation() {
    setSlideShowMode(false);
    setStep(ani.getFirstRealStep(), true);
  }

  /**
   * go back one step in the animation
   */
  public void backwardAnimation() {
    setSlideShowMode(false);
    setStep(ani.getPrevStep(), true);
  }

  /**
   * play the current animation step in reverse mode
   */
  public void reversePlay() {
    setSlideShowMode(false);
    forwardMode = false;
    setReverseStep(ani.getStep(), false);
  }

  /**
   * play the animation in reverse slide show mode
   */
  public void reverseSlideShow() {
    setSlideShowMode(true);
    forwardMode = false;
    pause = false;

    // show normally request delay now!
    setReverseStep(ani.getStep(), false);
  }

  /**
   * pause the animation
   */
  public void pauseAnimation() {
    pause = true;
    setSlideShowMode(false);
  }

  /**
   * play the current animation animation step in "normal" (forward) mode
   */
  public void playAnimation() {
    setSlideShowMode(false);
    setStep(ani.getNextStep(), false);
  }

  /**
   * play the animation in slide show mode
   */
  public void slideShow() {
    setSlideShowMode(true);
    forwardMode = true;
    pause = false;
    setStep(ani.getNextStep(), false);
  }

  /**
   * jump to the next animation step without animating the effects
   */
  public void forwardAnimation() {
    setSlideShowMode(false);
    setStep(ani.getNextStep(), true);
  }

  /**
   * jump to the end of the animation
   */
  public void endOfAnimation() {
    setSlideShowMode(false);
    setStep(ani.getLastStep(), true);
  }

  /**
   * toggle the slide show mode on / off
   * 
   * @param mode
   *          if true, use slide show mode, else do not use it.
   */
  public void setSlideShowMode(boolean mode) {
    slideShowMode = mode;
  }

  /**
   * returns the current slide show mode
   * 
   * @return true if in slide show mode, else false
   */
  public boolean getSlideShowMode() {
    return slideShowMode;
  }

  /**
   * set the current magnification factor to "factor"
   * 
   * @param factor
   *          the target magnification factor
   */
  public void setMagnification(double factor) {
    animationCanvas.setMagnification(factor);
  }

  /**
   * returns the scroll pane
   * 
   * @return the current scroll pane
   */
  public ScrollPane getScrollPane() {
    return sp;
  }

  /**
   * retrieves the current magnification factor of the display
   * 
   * @return the current magnification factor as a double
   */
  public double getMagnification() {
    return animationCanvas.getMagnification();
  }

  /**
   * activates or deactivates the animation control elements based on the value
   * passed in.
   * 
   * @param enabled
   *          is true, active the elements, else deactive them
   */
  public void enableControls(boolean enabled) {
    animationControlToolBar.enableControls(enabled);
  }

  /**
   * assigns the current button controller
   * 
   * @param controller
   *          the ButtonController for this instance of the animation window
   */
  public void setButtonController(ButtonController controller) {
    animationControlToolBar.setButtonController(controller);
  }

  /**
   * sets the step for the AnimationWindow.
   * 
   * @param step
   *          the target step
   * @param immediate
   *          if true, the state of the Animation after executing the step is
   *          displayed. If false, the Animators of this step are executed
   *          visibly. In the end, the same state is reached.
   */
  public void setStep(int step, boolean immediate) {
    int theStep = step;
    // forwardMode = true;

    if (isVisible()) { // don't work if the window is not visible anyway

      int next = 0;
      if (ani.getAnimation() == null)
        return;
      theStep = ani.getAnimation().verifyStep(theStep);

      if (ani != null) { // prepare the AnimationState object
        ani.setStep(theStep, !immediate);
      }

      AnimalMainWindow.getWindowCoordinator().getAnnotationEditor(false)
          .setCurrentStep(theStep);

      // update the step slider and step field
      animationControlToolBar.setStep(theStep, ani);

      // paint the objects directly...
      if (immediate) {
        animationCanvas.repaintNow();
        next = Link.END;
      } else {
        // ...or execute the Animators slowly
        next = nextStep();

        if (next != Link.END) {
          // the next step has to be executed right now because
          // there was a time link between the steps and the
          // pause button was not pressed
          theStep = next;
        }
      }

      // make only those buttons visible that actually have to be
      // visible, e.g. forwardButton must not be pressed if the
      // Animation is already at its end
      animationControlToolBar.determineButtonState(theStep);
    }
  }

  /**
   * sets the step for the AnimationWindow.
   * 
   * @param step
   *          the target animation step
   * @param immediate
   *          if true, the state of the Animation after executing the step is
   *          displayed. If false, the Animators of this step are executed
   *          visibly. In the end, the same state is reached.
   */
  public void setReverseStep(int step, boolean immediate) {
    int theStep = step;
    forwardMode = false;

    if (isVisible()) { // don't work if the window is not visible anyway

      int next = 0;
      theStep = ani.getAnimation().verifyStep(theStep);

      if (ani != null) { // prepare the AnimationState object
        ani.setStep(theStep, !immediate);
      }

      AnimalMainWindow.getWindowCoordinator().getAnnotationEditor(false)
          .setCurrentStep(theStep);

      animationControlToolBar.setStep(theStep, ani);

      // paint the objects directly...
      if (immediate) {
        animationCanvas.repaintNow();
        next = Link.END;
      } else {
        // ...or execute the Animators slowly
        next = reversePlayStep();

        if (next != Link.START) {
          // the next step has to be executed right now because
          // there was a time link between the steps and the
          // pause button was not pressed
          setStep(next, true);
        }

        theStep = next;
      }

      // make only those buttons visible that actually have to be
      // visible, e.g. forwardButton must not be pressed if the
      // Animation is already at its end
      animationControlToolBar.determineButtonState(theStep);
    }
  }

  /**
   * returns the current step
   * 
   * @return the current animation step
   */
  public int getStep() {
    return ani.getStep();
  }

  /**
   * executes one step by executing all Animators "slowly"(i.e. not at once but
   * according to their execution time).
   * 
   * @return next step to be executed immediately afterwards; Link.END, if none
   *         such step exists
   */
  public int nextStep() {
    Vector<Animator> animators; // Animators to execute in this step
    Animator animator; // Animator currently processed
    long time; // for synchronization
    forwardMode = true;

    int step = ani.getStep();

    // required because the playbutton can be pressed by pressing space
    // even when disabled!
    animationControlToolBar.enablePlayButton(false);

    // get the Animators that still have to be processed to reach the next
    // step. They are left by AnimationState.setStep if immediate was false.
    animators = ani.getCurrentAnimators();
    time = System.currentTimeMillis();

    // initialize each Animator by linking it with AnimationWindow's
    // AnimationState object and resetting its start time and ticks
    int initTicks = (int) Math.round(ticks);

    for (int a = 0; a < animators.size(); a++)
      animators.elementAt(a).init(ani, time, initTicks);

    boolean finished = false; // no more Animators to be processed?

    while (!finished) {
      finished = true;
      time = System.currentTimeMillis();

      // ticks++;
      ticks += speed;

      // execute each Animator slowly
      for (int a = 0; a < animators.size();) {
        animator = animators.elementAt(a);

        if (animator != null) {
          // perform an action on the Animator
          animator.action(time, ticks);

          // and if this was its last action, remove it from the
          // list of Animators to be processed
          if (animator.hasFinished()) {
            animators.removeElementAt(a);
          } else {
            // if it's not yet removed, it has to be processed once
            // more in the next loop.
            finished = false;
            a++;
          }
        }
      }

      // after all Animators have executed once, display the new state
      animationCanvas.repaintNow();

      if (isSlowMode) {
        // Image thisImage = animationCanvas.getCurrentImage();
        animationImages.addElement(animationCanvas.getCurrentImage());
        animationCanvas.invalidateImage();
      }
    }

    // check link to the next step
    Link l = ani.getAnimation().getLink(step);

    if (getSlideShowMode() && !pause) {
      int delay = l.getTime();

      if (delay == 0) {
        delay = Animal.getSlideShowDelay();
      }
      
      int targetDelay = (speed < 0.01) ? delay : 
        (int) Math.round(delay / speed);
      if (timer == null) {
        timer = new Timer(targetDelay, this);
      } else {
        timer.setDelay(targetDelay);
      }

      timer.setRepeats(false);
      timer.start();

      return l.getNextStep();
    } 
    switch (l.getMode()) {
    case Link.WAIT_KEY: // do not automatically process the next step
      return Link.END;
      
    case Link.WAIT_TIME:
      
      if (!pause) { // pause button has not been pressed
        int delay = l.getTime();
        
        if (delay == 0) {
          delay = Animal.getSlideShowDelay();
        }
        
        int targetDelay = (speed < 0.01) ? delay : 
          (int) Math.round(delay / speed);
        if (timer == null) {
          timer = new Timer(targetDelay, this);
        } else {
          timer.setDelay(targetDelay);
        }
        
        timer.setRepeats(false);
        timer.start();
        
        return l.getNextStep();
      } // !pause
      // pause button pressed. Then return that next step
      // must not be processed now
      pause = false;
      
      return Link.END;

      
    case Link.WAIT_CLICK:
      JOptionPane.showMessageDialog(this, l.getClickPrompt());
      
      // disable the controls -- are re-activated by
      // AnimationCanvasMouseListener if
      // the "right" object is hit.
      // enableControls(false);
      return Link.END;
      
      // case Link.REPEAT: // not yet implemented
      // if (pause || !pause) {
      // return l.breakStep;
      // } else {
      // return l.getNextStep();
      // }
      // break;
    } // switch


    animationControlToolBar.determineButtonState(step);

    // playButton.setEnabled(step != ani.getLastStep());
    return Link.END;
  } // nextStep()

  /**
   * executes one step by executing all Animators "slowly"(i.e. not at once but
   * according to their execution time).
   * 
   * @return next step to be executed immediately afterwards; Link.END, if none
   *         such step exists
   */
  public int reversePlayStep() {
    Vector<Animator> animators; // Animators to execute in this step
    Animator animator; // Animator currently processed
    long time; // for synchronization

    int step = ani.getStep();

    // Animal.logDebugInfo("current step (@end): " +step);
    // required because the playbutton can be pressed by pressing space
    // even when disabled!
    animationControlToolBar.enablePlayButton(false);

    // get the Animators that still have to be processed to reach the next
    // step. They are left by AnimationState.setStep if immediate was false.
    animators = ani.getCurrentAnimators();
    time = System.currentTimeMillis();

    int a = 0;
    Link currentLink = ani.getAnimation().getLink(step);
    int lengthOfStep = currentLink.getDurationInTicks();

    int initialTicks = (int) (Math.round(ticks));
    int referenceTicks = initialTicks + lengthOfStep;

    // initialize each Animator by linking it with AnimationWindow's
    // AnimationState object and resetting its start time and ticks
    Animator currentAnimator = null;

    for (a = 0; a < animators.size(); a++) {
      currentAnimator = animators.elementAt(a);
      if (currentAnimator != null) {
        currentAnimator.init(ani, time, initialTicks);
      }
    }

    boolean finished = false; // no more Animators to be processed?

    while (!finished) {
      finished = true;
      time = System.currentTimeMillis();
      referenceTicks -= speed;
      ticks += speed;

      // execute each Animator slowly
      for (a = 0; a < animators.size(); a++) {
        animator = animators.elementAt(a);
        animator.setFinished(false);

        // perform an action on the Animator
        animator.action(time, referenceTicks);
      }

      // after all Animators have executed once, display the new state
      animationCanvas.repaintNow();
      finished = initialTicks >= referenceTicks;
    }

    // check link from the previous step
    int prevStep = ani.getPrevStep();

    Link l = ani.getAnimation().getLink(ani.getPrevStep());

    if (getSlideShowMode() && !pause) {
      int delay = l.getTime();

      if (delay == 0) {
        delay = Animal.getSlideShowDelay();
      }

      if (timer == null) {
        timer = new Timer(delay, this);
      } else {
        timer.setDelay(delay);
      }

      timer.setRepeats(false);
      timer.start();

      // return l.getNextStep();
      // Animal.logDebugInfo("Slide show mode... step number: " +prevStep);
      return prevStep;
    } 
    switch (l.getMode()) {
    case Link.WAIT_KEY: // do not automatically process the next step
      
      // return Link.END;
      // Animal.logDebugInfo("*** @switch WAIT_KEY, return " +prevStep);
      return prevStep;
      
    case Link.WAIT_TIME:
      /*
       * if (!pause) { // pause button has not been pressed
       * 
       * if (timer == null) { timer = new Timer(l.getTime(), this); } else {
       * timer.setDelay(l.getTime()); }
       * 
       * timer.setRepeats(false); // timer.setCoalesce(true); timer.start(); //
       * Animal.logDebugInfo("Next step in reverse direction: " +prevStep);
       * return prevStep; } // !pause else { // pause button pressed. Then
       * return that next step // must not be processed now pause = false; //
       * Animal.logDebugInfo("*** @switch WAIT_TIME, not paused, return "
       * +prevStep); return prevStep; // return Link.END; }
       */
      return prevStep;
      // case Link.REPEAT: // not yet implemented
      // if (pause || !pause) {
      // return l.breakStep;
      // } else {
      // return l.getNextStep();
      // }
      // break;
    } // switch


    // playButton.setEnabled(step != Link.START);
    // Animal.logDebugInfo("current step number: " +step);
    animationControlToolBar.determineButtonState(step);

    // Animal.logDebugInfo("*** finally return " +prevStep);
    return prevStep;

    // return Link.END;
  } // nextStep()

  /**
   * executes one step by executing all Animators "slowly"(i.e. not at once but
   * according to their execution time).
   * 
   * @return next step to be executed immediately afterwards; Link.END, if none
   *         such step exists
   */
  public Rectangle determineImageSize() {
    Vector<Animator> animators; // Animators to execute in this step
    Animator animator; // Animator currently processed
    long time; // for synchronization
    Rectangle size = new Rectangle(0, 0, 1, 1);
    int step = Link.START;
    ani.setStep(Link.START, false);

    for (step = ani.getNextStep(); step != Link.END; step = ani.getNextStep()) {
      ani.setStep(step, false);
      animators = ani.getCurrentAnimators();
      time = System.currentTimeMillis();

      // initialize each Animator by linking it with AnimationWindow's
      // AnimationState object and resetting its start time and ticks
      int initialTicks = (int) (Math.round(ticks));
      ticks = initialTicks;

      for (int a = 0; a < animators.size(); a++)
        animators.elementAt(a).init(ani, time, initialTicks);

      boolean finished = false; // no more Animators to be processed?
      int[] currentObjects = null;
      PTGraphicObject currentObject = null;

      while (!finished) {
        finished = true;
        time = System.currentTimeMillis();
        ticks++;

        // execute each Animator slowly
        for (int a = 0; a < animators.size();) {
          animator = animators.elementAt(a);

          // perform an action on the Animator
          animator.action(time, ticks);
          currentObjects = animator.getObjectNums();

          for (int i = 0; i < currentObjects.length; i++) {
            currentObject = ani.getCloneByNum(currentObjects[i]);
            size = SwingUtilities.computeUnion(0, 0, size.width, size.height,
                currentObject.getBoundingBox());
          }

          // and if this was its last action, remove it from the
          // list of Animators to be processed
          if (animator.hasFinished()) {
            animators.removeElementAt(a);
          } else {
            // if it's not yet removed, it has to be processed once
            // more in the next loop.
            finished = false;
            a++;
          }
        }
      }
    }

    return size;
  } // determineImageSize()

  /**
   * sets the Animation for the AnimationWindow. If the window is visible, the
   * current step will be displayed.
   * 
   * @param animation
   *          the new animation
   */
  void setAnimation(Animation animation) {
    if (!isInitialized()) {
      init();
    }

    ani = new AnimationState(animation);

    GraphicVector objects = ani.getCurrentObjects();
    animationCanvas.setObjects(objects);
    setStep(ani.getStep(), true);
    ticks = 0;
    ani.reset();
    if (animation != null) {
      int w = animation.getWidth(), h = animation.getHeight();
      if ((animation.getWidth() > 0 && animation.getHeight() > 0)
          && w > getWidth() - PADDING_SCROLLBAR_RIGHT
          && h > getHeight() - PADDING_TOOLBARS_TOP_BOTTOM) {
        // setSize(w + PADDING_SCROLLBAR_RIGHT, h +
        // PADDING_TOOLBARS_TOP_BOTTOM);
        setSize(w, h);
      }
      animationControlToolBar.setNrOfSteps(animation.getNrOfSteps() - 1);
    }
    animationControlToolBar.enablePlayButton(true);
  }

  /**
   * generates a String label for the step number passed in
   * 
   * @param stepNr
   *          the target step number
   * @return a String representation of the step number
   */
  public String setLabelForStep(int stepNr) {
    return String.valueOf(stepNr);
  }

  /**
   * returns the AnimationCanvas instance on which the elements are painted
   * 
   * @return the current AnimationCanvas
   */
  public AnimationCanvas getAnimationCanvas() {
    return animationCanvas;
  }

  /**
   * returns the current animation state as an Image
   * 
   * @return an image representing the current animation state
   */
  public Image getCurrentImage() {
    return animationCanvas.getCurrentImage();
  }

  /**
   * sets the current display mode to "slow" or "normal"
   * 
   * @param isSlow
   *          if true, activate "slow mode"
   */
  public void setSlowMode(boolean isSlow) {
    isSlowMode = isSlow;
  }

  public void setSpeed(double speedValue) {
    if (speedValue > 0 && speedValue <= OldAnimationWindow.MAX_SPEED_FACTOR)
      speed = speedValue;
  }

  /**
   * determines the current status of the "slow mode" (on or off)
   * 
   * @return true if the animation is in "slow mode"
   */
  public boolean getSlowMode() {
    return isSlowMode;
  }

  /**
   * handles action events, which are always caused by the animation timer
   * 
   * @param actionEvent
   *          the event to be handled
   */
  public void actionPerformed(ActionEvent actionEvent) {
    if (actionEvent.getSource() == timer) {
      // boolean continueLoop = !pause;

      if (!pause)// {
      // while (continueLoop)
      {
        // determine current step and next step to show (previous/next step)
        int nextStep = Link.END;

        // determine current step and next step to show (previous/next step)
        // int thisStep = ani.getStep();
        // Link l = null;

        if (forwardMode) {
          nextStep = ani.getNextStep();
          // l = ani.getAnimation().getLink(thisStep);
        } else {
          nextStep = ani.getPrevStep();
          // l = ani.getAnimation().getLink(nextStep);
        }

        if (forwardMode && (nextStep != Link.END)) {
          setStep(nextStep, false);
        } else if (!forwardMode && (nextStep != Link.START)) {
          setReverseStep(nextStep, false);
        }

        // continue if not paused and (stepDelay > 0 || slide show mode active)
        // continueLoop = !pause && ((l.getTime() > 0) || getSlideShowMode()) &&
        // (nextStep != Link.START) && (nextStep != Link.END);
      }
    }
  }

  /**
   * returns the current animation state object
   * 
   * @return the current state of the animation
   */
  public AnimationState getAnimationState() {
    return ani;
  }

  /**
   * provides access to the AnimationControlToolBar. This is needed to enable
   * applications to decide if the controls should be turned on or off.
   * 
   * @return the AnimationControlToolBar of this AnimationWindow
   */
  protected AnimationControlToolBar getAnimationControlToolBar() {
    return animationControlToolBar;
  }

  /**
   * returns a set of images describing the current animation
   * 
   * @return an image array containing visual representations of the animation
   *         state
   */
  public Image[] getAnimationImages() {
    if (animationImages.size() == 0) {
      return new Image[] { animationCanvas.getCurrentImage() };
    }

    Image[] images = new Image[animationImages.size()];
    animationImages.copyInto(images);
    animationImages.clear();

    return images;
  }
}

