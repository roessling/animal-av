/*
 * Created on 30.11.2005 by Guido Roessling (roessling@acm.org>
 */
package animal.main;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.LinkedList;
import java.util.List;
import java.util.Vector;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.Timer;

import animal.animator.Animator;
import animal.api.AnimalStepListener;
import animalscript.core.AnimalScriptParser;

public class AnimationController implements ActionListener {
	AnimalScriptParser aSP = null;

	AnimalConfiguration animalConfig;

	Animation animation;

	AnimationCanvas animationCanvas;

	AnimationState ani;

	boolean pause, forwardMode, slideShowMode;

	double ticks, speed = 1.0;

	Timer timer;

	JFrame frame;

	private JButton play;
	
	private List<AnimalStepListener> animalStepListeners;
	
	public AnimationController(Animation anim, AnimationCanvas canvas,
			AnimationState animState) {
		animalStepListeners = new LinkedList<AnimalStepListener>();
		setAnimationCanvas(canvas);
		setAnimation(anim);
		setAnimationState(animState);
	}

	/**
	 * Adds an AnimalStepListener to the list of registered listeners.
	 * 
	 * @param listener
	 *          the listener to add
	 */
	public void addAnimalStepListener(AnimalStepListener listener) {
		animalStepListeners.add(listener);
	}
	
	/**
	 * Removes an AnimalStepListener from the list of registered listeners.
	 * 
	 * @param listener
	 *          the listener to remove
	 */
	public void removeAnimalStepListener(AnimalStepListener listener) {
		animalStepListeners.remove(listener);
	}

	public Animation getAnimation() {
		return animation;
	}

	public void setAnimation(Animation newAnim) {
		animation = newAnim;
		setAnimationState(new AnimationState(animation));
		getAnimationState().reset();
		int stepNr = getAnimationState().getStep();
		if (stepNr == Link.START)
			stepNr = getAnimationState().getFirstRealStep();
		getAnimationState().setStep(stepNr, true);
	}

	public AnimationState getAnimationState() {
		return ani;
	}

	public void setAnimationState(AnimationState animState) {
		ani = animState;
		getAnimationCanvas().setObjects(ani.getCurrentObjects());
		setStep(ani.getFirstRealStep(), true);
	}

	public AnimationCanvas getAnimationCanvas() {
		return animationCanvas;
	}

	public void setAnimationCanvas(AnimationCanvas canvas) {
		animationCanvas = canvas;
	}

	/**
	 * sets the step for the AnimationWindow.
	 * 
	 * @param step
	 *          the target step
	 * @param immediate
	 *          if true, the state of the Animation after executing the step is
	 *          displayed. If false, the Animators of this step are executed
	 *          visibly. In the end, the same state is reached.
	 */
	public void setStep(int step, boolean immediate) {
	  int theStep = step;
		forwardMode = true;

		// if (isVisible()) { // don't work if the window is not visible anyway

		int next = 0;
		theStep = ani.getAnimation().verifyStep(theStep);

		if (ani != null) { // prepare the AnimationState object
			ani.setStep(theStep, !immediate);
		}

		// paint the objects directly...
		if (immediate) {
			animationCanvas.repaintNow();
			next = Link.END;
		} else {
			// ...or execute the Animators slowly
			next = nextStep();

			if (next != Link.END) {
				// the next step has to be executed right now because
				// there was a time link between the steps and the
				// pause button was not pressed
			  theStep = next;
			}
		}
		
		for (AnimalStepListener listener : animalStepListeners) 
			listener.stepSet(theStep, immediate);
	}

	/**
	 * executes one step by executing all Animators "slowly"(i.e. not at once but
	 * according to their execution time).
	 * 
	 * @return next step to be executed immediately afterwards; Link.END, if none
	 *         such step exists
	 */
	public int nextStep() {
		Vector<Animator> animators; // Animators to execute in this step
		Animator animator; // Animator currently processed
		long time; // for synchronization
		forwardMode = true;

		int step = ani.getStep();

		// required because the playbutton can be pressed by pressing space
		// even when disabled!
		// animationControlToolBar.enablePlayButton(false);

		// get the Animators that still have to be processed to reach the next
		// step. They are left by AnimationState.setStep if immediate was false.
		animators = ani.getCurrentAnimators();
		time = System.currentTimeMillis();

		// initialize each Animator by linking it with AnimationWindow's
		// AnimationState object and resetting its start time and ticks
		int initTicks = (int) Math.round(ticks);

		for (int a = 0; a < animators.size(); a++)
			animators.elementAt(a).init(ani, time, initTicks);

		boolean finished = false; // no more Animators to be processed?

		while (!finished) {
			finished = true;
			time = System.currentTimeMillis();

			// ticks++;
			ticks += speed;

			// execute each Animator slowly
			for (int a = 0; a < animators.size();) {
				animator = animators.elementAt(a);

				if (animator != null) {
					// perform an action on the Animator
					animator.action(time, ticks);

					// and if this was its last action, remove it from the
					// list of Animators to be processed
					if (animator.hasFinished()) {
						animators.removeElementAt(a);
					} else {
						// if it's not yet removed, it has to be processed once
						// more in the next loop.
						finished = false;
						a++;
					}
				}
			}

			// after all Animators have executed once, display the new state
			animationCanvas.repaintNow();
		}

		// check link to the next step
		Link l = ani.getAnimation().getLink(step);

		if (slideShowMode && !pause) {
			int delay = l.getTime();

			if (delay == 0) {
				delay = Animal.getSlideShowDelay();
			}

			if (timer == null) {
				timer = new Timer(delay, this);
			} else {
				timer.setDelay(delay);
			}

			timer.setRepeats(false);
			timer.start();

			return l.getNextStep();
		}

		switch (l.getMode()) {
		case Link.WAIT_KEY: // do not automatically process the next step
			return Link.END;

		case Link.WAIT_TIME:

			if (!pause) { // pause button has not been pressed

				if (timer == null) {
					timer = new Timer(l.getTime(), this);
				} else {
					timer.setDelay(l.getTime());
				}

				timer.setRepeats(false);
				timer.start();

				return l.getNextStep();
			} // !pause
			
			// pause button pressed. Then return that next step
			// must not be processed now
			pause = false;

			return Link.END;


		case Link.WAIT_CLICK:
			JOptionPane.showMessageDialog(null, l.getClickPrompt());

			// disable the controls -- are re-activated by
			// AnimationCanvasMouseListener if
			// the "right" object is hit.
			// enableControls(false);
			return Link.END;
		} // switch

		// animationControlToolBar.determineButtonState(step);

		// playButton.setEnabled(step != ani.getLastStep());
		return Link.END;
	} // nextStep()

	/**
	 * Pause the visualization at the current frame. This method should make a
	 * call to play unblock immeditatlly if possible.
	 */
	public void pause() {
		pause = true;
		slideShowMode = false;
	}

	/**
	 * Step back one frame, animating if necessary. This method must block until
	 * the animation or frame change is complete.
	 */
	public void stepBackward() {
		slideShowMode = false;
		if (ani.getPrevStep() != Link.START)
			setStep(ani.getPrevStep(), true);
	}

	/**
	 * Step forward one frame, animating if necessary. This method must block
	 * until the animation or frame change is complete.
	 */
	public void stepForward() {
		slideShowMode = false;
		setStep(ani.getNextStep(), false);
	}

	/**
	 * Play several frames in succession. This method must block until it reaches
	 * the end of the script or pause / stop are called. If pause or stop is
	 * called then play should stop play immediatlly if possible and unblock /
	 * return.
	 */
	public void play() {
		slideShowMode = true;
		forwardMode = true;
		pause = false;
		setStep(ani.getNextStep(), false);
	}

	/**
	 * Play several frames in succession. This method must block until it reaches
	 * the end of the script or pause / stop are called. If pause or stop is
	 * called then play should stop play immediatlly if possible and unblock /
	 * return.
	 */
	public void reversePlay() {
		slideShowMode = true;
		forwardMode = false;
		pause = false;
		setStep(ani.getStep(), false);
	}

	/**
	 * Go directly to the given frame, do not animate to it. This method should
	 * not block.
	 * 
	 * @param aFrame
	 *          the frame / key frame number to go to, zero based.
	 */
	public void gotoFrame(int aFrame) {
	  int theFrame = aFrame;
		if (theFrame == 0)
		  theFrame = 1;
		setStep(theFrame, true);
	}

	/**
	 * Stops a visualizer from playing and returns to the first frame.
	 */
	public void stop() {
		pause(); // first, pause the animation
		setStep(ani.getFirstRealStep(), true); // then go to first step
	}

	/**
	 * returns the current slide show mode
	 * 
	 * @return true if in slide show mode, else false
	 */
	public boolean getSlideShowMode() {
		return slideShowMode;
	}

	/**
	 * toggle the slide show mode on / off
	 * 
	 * @param mode
	 *          if true, use slide show mode, else do not use it.
	 */
	public void setSlideShowMode(boolean mode) {
		slideShowMode = mode;
	}

	/**
	 * Set the zoom of the visualizer to the specified level. The parameter is a
	 * percentage with 1.0 being 100% or default zoom.
	 * 
	 * @param level
	 *          zoom percentage.
	 */
	public void zoom(double level) {
		animationCanvas.setMagnification(level);
	}

	/**
	 * Returns the current zoom level.
	 * 
	 * @return current zoom level.
	 */
	public double getZoom() {
		return animationCanvas.getMagnification();
	}

	/**
	 * handles action events, which are always caused by the animation timer
	 * 
	 * @param actionEvent
	 *          the event to be handled
	 */
	public void actionPerformed(ActionEvent actionEvent) {
		if (actionEvent.getSource() == play) {
			stepForward();
		}
		if (actionEvent.getSource() == timer) {
			// boolean continueLoop = !pause;

			if (!pause)// {
			// while (continueLoop)
			{
				// determine current step and next step to show (previous/next step)
				int nextStep = Link.END;

				// determine next step to show (previous/next step)
				if (forwardMode) {
					nextStep = ani.getNextStep();
				} else {
					nextStep = ani.getPrevStep();
				}

				if (forwardMode && (nextStep != Link.END)) {
					setStep(nextStep, false);
				}

				// // continue if not paused and (stepDelay > 0 || slide show mode
				// active)
				// continueLoop = !pause && ((l.getTime() > 0) || getSlideShowMode()) &&
				// (nextStep != Link.START) && (nextStep != Link.END);
			}
		}
	}
}
