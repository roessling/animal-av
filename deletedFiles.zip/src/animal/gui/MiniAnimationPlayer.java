package animal.gui;


import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.util.Locale;

import javax.swing.AbstractButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.Timer;

import translator.Translator;
import animal.main.Animal;
import animal.main.AnimalConfiguration;
import animal.main.Animation;
import animal.main.AnimationCanvas;
import animal.main.AnimationController;
import animal.main.AnimationListEntry;
import animal.main.AnimationState;
import animal.main.Link;
import animalscript.core.AnimalScriptParser;
import animalscript.core.BasicParser;

public class MiniAnimationPlayer implements ActionListener {
	AnimalConfiguration animalConfig;
	Animation animation;
	AnimationCanvas animationCanvas;
	boolean pause, forwardMode, slideShowMode;
	double ticks, speed = 1.0;
	Timer timer;
	JFrame frame;
	private AbstractButton playButton, pauseButton, playReverseButton, slideShowButton,
	magicButton;
	AnimationController controller;
	
	/**
	 * Set up the components and then creates the JFrame
	 */
	public MiniAnimationPlayer(int width, int height) {
		initConfig(width, height);
  }
	
	
	/**
	 * initializes the components
	 * You should not have to edit this code.
	 */
	public void initConfig(int width, int height) {
		Animal animal = Animal.get();
		animal.setAutoloadLastFile(false);
		
		// retrieve the configuration to initialize all components
		animalConfig = Animal.getAnimalConfiguration();
		// was: AnimalMainWindow mainWindow = 
		new AnimalMainWindow(animal,
				animalConfig.getProperties(),
				false, true);
		animalConfig.initializeAllEditors();
		animation = new Animation();
		Animal.setAnimationLoadFinished(false);	
    animationCanvas = new AnimationCanvas();
    animationCanvas.initSize();
    animationCanvas.setExplicitSize(new Dimension(width, height));
    animationCanvas.setVisible(true);
		frame = new JFrame("Demo Frame");
		frame.getContentPane().setLayout(new BorderLayout());
    frame.getContentPane().add(BorderLayout.CENTER, animationCanvas);
    // reserve space for the button row!
    frame.setSize(width, height + 50);
    createButtons();
    frame.setVisible(true);    
    frame.repaint();
	}
	
	/**
	 * convenience method, leave as is...
	 * @param useANewOne
	 * @return the current parser
	 */
	public AnimalScriptParser getParser(boolean useANewOne) {
		AnimalScriptParser aSP = Animal.getAnimalScriptParser(useANewOne);
		return aSP;
	}
	
	/**
	 * convenience method, leave as is...
	 * @return the current animation
	 */
	public Animation getAnimation() {
		return animation;
	}
	
	/**
	 * you should not edit this code.
	 * 
	 * @param newAnim the new animation to be set
	 */
	public void setAnimation(Animation newAnim) {
		animation = newAnim;
    if (controller == null)
    	controller = new AnimationController(animation, animationCanvas, 
    			new AnimationState(animation));
    else {
    	controller.setAnimation(animation);
    }
	}

	/**
	 * Creates the graphical interface - feel free to modify this!
	 */
	private void createButtons() {
    Translator translator = new Translator("AnimationPlayer", Locale.GERMANY);
    JPanel panel = new JPanel();
    panel.setLayout(new GridLayout(1, 0));

    pauseButton = translator.getGenerator().generateJButton("pauseButton",
    		null, false, this);
    panel.add(pauseButton);

    playReverseButton = translator.getGenerator().generateJButton("playReverseButton",
    		null, false, this);
    panel.add(playReverseButton);

    playButton = translator.getGenerator().generateJButton("playButton",
    		null, false, this);    
    panel.add(playButton);
    
    slideShowButton = translator.getGenerator().generateJButton("slideShowButton",
    		null, false, this);
    panel.add(slideShowButton);
    
    magicButton = translator.getGenerator().generateJButton("magicButton",
    		null, false, this);
    panel.add(magicButton);
    
    frame.getContentPane().add(BorderLayout.SOUTH, panel);
	}
	
	
	/**
	 * No longer needed, but very useful for debugging
	 * @param a the animation to dump to System.err
	 */
	public void dumpAnimation(Animation a) {
		if (a == null)
			System.err.println("null");
		else {
  		AnimationListEntry[] entries = a.getAnimatorList();
      if (entries != null) {
  			StringBuilder sbuffer = new StringBuilder(entries.length*80);
        // iterate all lines of the list
        for (int i = 0; i < entries.length; i++) {
          AnimationListEntry ai = entries[i];
          // and if it's an Animator or a link, recalculate its message
          if (ai.mode == AnimationListEntry.ANIMATOR)
          	sbuffer.append(ai.animator.toString());
          if (ai.mode == AnimationListEntry.STEP)
          	sbuffer.append(ai.link.toString());
          sbuffer.append("\n");
        }
        System.err.println(sbuffer.toString());
      }
		}
	}

	/**
	 * runs the demo: creates the initial animation code.
	 * 
	 * You probably want to replace this with something more "useful"!
	 */
	public void runDemo() {
//		String demoAnim = "%Animal 2\nsquare \"s\" (10, 10) 30 filled fillColor red\nmove \"s\" along line (10, 10) (30, 30) within 10 ticks";
		AnimalScriptParser parser = getParser(true);
		String animContents = readAnimationFromFile("C:\\Java\\temp.asu");
		if (BasicParser.stok == null) {
//			parser.generateStreamTokenizer(demoAnim, false);
			parser.generateStreamTokenizer(animContents,
					false);
		}
		Animation anim = parser.importAnimationFrom(new StringReader(animContents),
        true);
		setAnimation(anim);
	}
	
	public String readAnimationFromFile(String filename) {
		StringBuilder fileContents = new StringBuilder(65536);
		try {
			InputStreamReader isr = null;
				isr = new InputStreamReader(new FileInputStream(filename));
			BufferedReader br = new BufferedReader(isr);
			String currentLine = null;
			while ((currentLine = br.readLine()) != null)
				fileContents.append(currentLine).append("\n");
			br.close();
		} catch(Exception e) {
			System.err.println(e.getMessage());
		}
		return fileContents.toString();
	}
	
	public void validateButtons() {
		AnimationState cState = controller.getAnimationState();
		// play, slide show: only enabled if not at final step
		playButton.setEnabled((cState.getNextStep() != Link.END));
		slideShowButton.setEnabled((cState.getNextStep() != Link.END));
		
		// pause: any time
		// playReverse: only enabled if not at first step
		playReverseButton.setEnabled((cState.getPrevStep() != Link.START));
  }

  /**
   * handles action events, which are always caused by the animation timer
   * 
   * @param actionEvent the event to be handled
   */
  public void actionPerformed(ActionEvent actionEvent) {
  	Object source = actionEvent.getSource();
  	if (source == pauseButton) {
  		if (controller != null)
  			controller.pause();
  	} else if (source == playButton) {
  		if (controller != null) {
  			AnimationState cState = controller.getAnimationState();
   			if (cState.getNextStep() != Link.END)
   				controller.stepForward();
  		}
  	} else if (source == playReverseButton) {
  		if (controller != null)
  			controller.stepBackward();
  	} else if (source == slideShowButton) {
  		if (controller != null)
  			controller.play();
  	}	else if (source == magicButton) {
  		int currentStep = controller.getAnimationState().getStep();
  		String secondPart = "\ntriangle \"t\" (10, 10) (20, 20) (10, 20) filled fillColor cyan\nmove \"t\" \"s\" along line (10, 10) (20, 20) within 1000 ms";
  		AnimalScriptParser parser = getParser(false);
  		parser.generateStreamTokenizer(secondPart, false);
  		Animation anim2 = null;
  		try {
  			anim2 = parser.programImport(false);
  		} catch (IOException e) {
  			System.err.println("Could not load in animation for some reason...");
  		}
  		anim2.resetChange();
  		setAnimation(anim2);
  		controller.setStep(currentStep, true);
  	}	else if (source == timer) {
  		System.err.println("MUST NOT HAPPEN THAT WE CALL timer on XXDemo!");
    }
  	validateButtons();
  }
  
  // The following methods are not really needed at the moment, as there is no
  // zoom button :-)
  
  /**
   * Set the zoom of the visualizer to the specified level. The parameter is a
   * percentage with 1.0 being 100% or default zoom.
   * 
   * @param level
   *            zoom percentage.
   */
  public void zoom(double level) {
  	animationCanvas.setMagnification(level);
  }
  
  /**
   * Returns the current zoom level.
   * 
   * @return current zoom level.
   */
  public double getZoom() {
  	return animationCanvas.getMagnification();
  }


	public static void main(String[] args) {
		MiniAnimationPlayer x = new MiniAnimationPlayer(640, 480);
		x.runDemo();
	}
}
